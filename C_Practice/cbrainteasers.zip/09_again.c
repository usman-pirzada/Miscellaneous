#include <stdio.h>

int main()
{
	int a = 11;

	do
	{
		printf("a = %d\n",a);
		a--;
	}
	while(a<10);

	return(0);
}
