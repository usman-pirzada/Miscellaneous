#include <stdio.h>

int main()
{
	char nonstring[] = {
		'g', 'r', 'e', 'e', 't',
		'i', 'n', 'g', 's', ',',
		' ', 'h', 'u', 'm', 'a', 'n'
	};

	printf("%s\n",nonstring);

	return(0);
}
