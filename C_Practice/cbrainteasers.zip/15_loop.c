#include <stdio.h>

int main()
{
	char a;

	for( a=0; a<200; a++ )
		printf("%3d ",a);
	putchar('\n');

	return(0);
}
