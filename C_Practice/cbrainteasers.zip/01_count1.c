#include <stdio.h>
#include <math.h>

int main()
{
	printf("%2.4f\n",M_PI);

	return(0);
}
