#include <stdio.h>

int main()
{
	int u,d;

	for( u=0, d=0; u<11; u++, d-- )
		printf("%2d %2d\n",u,d);

	return(0);
}
