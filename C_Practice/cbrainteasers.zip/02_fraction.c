#include <stdio.h>

int main()
{
	int a,b;

	a = 5; b = 4;
	printf("%d/%d = %f\n",a,b,(float)a/b);

	return(0);
}
