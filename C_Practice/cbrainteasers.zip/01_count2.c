#include <stdio.h>
#include <math.h>

int main()
{
	int n;

	n = printf("%2.4f\n",M_PI);
	printf("(That's %d characters)\n",n);

	return(0);
}
