#include <stdio.h>

typedef int stinky;

stinky main()
{
    stinky a = 2;

    printf("Everyone knows that ");
    printf("%d + %d = %d\n",a,a,a+a);
    return(0);
}
