#include <stdio.h>

int main()
{
    puts("Greetings, human.");
    return 0;
}
