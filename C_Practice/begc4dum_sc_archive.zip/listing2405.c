#include <stdio.h>
#include <stdlib.h>

/* structures */
struct thing {
    char name[32];
    int age;
    };
typedef struct thing human;

/* prototypes */

void fillstructure(void);
void printstructure(void);

/* defined constants */

/* variables */
