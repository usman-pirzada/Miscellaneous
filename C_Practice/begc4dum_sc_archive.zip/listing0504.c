#include <stdio.h>

int main()
{
	printf("%d/%d=%d\n",2,5,2/5);
    return(0);
}
