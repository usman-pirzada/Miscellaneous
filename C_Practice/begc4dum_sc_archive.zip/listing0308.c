#include <stdio.h>

int main()
{
	printf("4 times 5 is %d\n",4*5);
	return(0);
}
