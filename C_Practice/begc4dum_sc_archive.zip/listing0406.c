#include <stdio.h>

int main()
{
    writeln("Another horrible mistake.");
    return(0);
}
