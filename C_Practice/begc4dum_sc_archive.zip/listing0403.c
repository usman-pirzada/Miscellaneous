#include <stdio.h>

int main()
{
    puts("The secret password is:");
/*  puts("Spatula."); */
    return(0);
}
