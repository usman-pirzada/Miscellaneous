#include <stdio.h>

int main()
{
    puts("This program goes BOOM!)
    return(0);
}
