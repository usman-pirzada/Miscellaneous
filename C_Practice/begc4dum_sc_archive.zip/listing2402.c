#include <stdio.h>

void second(void)
{
    puts("Glad to be here!");
}
