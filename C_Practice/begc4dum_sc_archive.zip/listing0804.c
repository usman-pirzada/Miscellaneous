#include <stdio.h>

int main()
{
	int a;

	a = 5;

	if(a=-3)
	{
		printf("%d equals %d\n",a,-3);
	}
	return(0);
}
