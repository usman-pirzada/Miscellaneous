#include <stdio.h>

int main()
{
    printf("I have been a stranger in a strange land.");
    return(0);
}
