#include <stdio.h>

int main()
{
    printf("The total is %d\n",16+17);
    return(0);
}
