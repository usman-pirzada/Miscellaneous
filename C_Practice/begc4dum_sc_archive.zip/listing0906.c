#include <stdio.h>

int main()
{
    int x;

    x=0;
    while(x<10)
    {
       puts("Sore shoulder surgery");
       x=x+1;
    }
    return(0);
}
