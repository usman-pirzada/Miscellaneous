#include <stdio.h>

int main()
{
    puts("Don't bother me now. I'm busy.");
    return(0);
}
