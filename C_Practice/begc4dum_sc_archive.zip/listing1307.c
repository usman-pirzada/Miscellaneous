#include <stdio.h>

int main()
{
    printf("%-9s me\n","meet");
    printf("%-8s me\n","meet");
    printf("%-7s me\n","meet");
    printf("%-6s me\n","meet");
    printf("%-5s me\n","meet");
    printf("%-4s me\n","meet");
    return(0);
}
