#include <stdio.h>

int main()
{
	int a,b;

	a = 5;
	b = -3;

	if(a==b);
		printf("%d equals %d\n",a,b);
	return(0);
}
