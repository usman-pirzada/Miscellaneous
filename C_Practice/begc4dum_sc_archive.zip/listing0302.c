/* Author: Dan Gookin 
   This program displays text on the screen */

#include <stdio.h>    /* Required for puts() */

int main()
{
    puts("Greetings, human.");  /* Displays text */
    return 0;
}
