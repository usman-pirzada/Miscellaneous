#include <stdio.h>

int main()
{
    int start = 0;

    printf("The starting value is %d.\n",start);
    return(0);
}
