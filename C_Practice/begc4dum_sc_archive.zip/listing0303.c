#include <stdio.h> 

int main()
{
    puts("Greetings, human.");  // Displays text
    return 0;
}
